1:"$Sreact.fragment"
2:I[85218,["8720","static/chunks/8720-6c3c0c904bca3f2e.js","1755","static/chunks/1755-103520aaab3b2467.js","7177","static/chunks/app/layout-f40989d1e2f1b16b.js"],"AuthProvider"]
3:I[9766,[],""]
4:I[98924,[],""]
5:I[18720,["8720","static/chunks/8720-6c3c0c904bca3f2e.js","1755","static/chunks/1755-103520aaab3b2467.js","7177","static/chunks/app/layout-f40989d1e2f1b16b.js"],"Toaster"]
6:I[57176,["8720","static/chunks/8720-6c3c0c904bca3f2e.js","1755","static/chunks/1755-103520aaab3b2467.js","7177","static/chunks/app/layout-f40989d1e2f1b16b.js"],"SessionWatcher"]
7:I[81959,[],"ClientPageRoot"]
8:I[37322,["4909","static/chunks/4909-f5e5a2b9645891bd.js","8720","static/chunks/8720-6c3c0c904bca3f2e.js","1366","static/chunks/1366-8f9046e99358a600.js","852","static/chunks/852-7823cd854f1fc767.js","1755","static/chunks/1755-103520aaab3b2467.js","3833","static/chunks/3833-91216ed696806599.js","3828","static/chunks/3828-7468c474914ab1f2.js","7361","static/chunks/7361-2789e3af6a4ea9c2.js","4424","static/chunks/4424-790cee7f2b45df28.js","9268","static/chunks/9268-b5db012ac067bae4.js","8974","static/chunks/app/page-6d503432a97f4994.js"],"default"]
b:I[24431,[],"OutletBoundary"]
d:I[15278,[],"AsyncMetadataOutlet"]
f:I[24431,[],"ViewportBoundary"]
11:I[24431,[],"MetadataBoundary"]
12:"$Sreact.suspense"
14:I[57150,[],""]
:HL["/_next/static/css/84edd78de243cde6.css","style"]
:HL["/_next/static/css/bbf9ac94693e31c6.css","style"]
0:{"P":null,"b":"j4ntXNjcczNJqHwfgV9rP","p":"","c":["",""],"i":false,"f":[[["",{"children":["__PAGE__",{}]},"$undefined","$undefined",true],["",["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/css/84edd78de243cde6.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","link","1",{"rel":"stylesheet","href":"/_next/static/css/bbf9ac94693e31c6.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]],["$","html",null,{"lang":"en","children":["$","$L2",null,{"children":["$","body",null,{"className":"__variable_246ccd __variable_4c40f6 antialiased","children":[["$","$L3",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L4",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":{"fontFamily":"system-ui,\"Segoe UI\",Roboto,Helvetica,Arial,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\"","height":"100vh","textAlign":"center","display":"flex","flexDirection":"column","alignItems":"center","justifyContent":"center"},"children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],["$","h1",null,{"className":"next-error-h1","style":{"display":"inline-block","margin":"0 20px 0 0","padding":"0 23px 0 0","fontSize":24,"fontWeight":500,"verticalAlign":"top","lineHeight":"49px"},"children":404}],["$","div",null,{"style":{"display":"inline-block"},"children":["$","h2",null,{"style":{"fontSize":14,"fontWeight":400,"lineHeight":"49px","margin":0},"children":"This page could not be found."}]}]]}]}]],[]],"forbidden":"$undefined","unauthorized":"$undefined"}],["$","$L5",null,{"position":"top-right","richColors":true}]," ",["$","$L6",null,{}]]}]}]}]]}],{"children":["__PAGE__",["$","$1","c",{"children":[["$","$L7",null,{"Component":"$8","searchParams":{},"params":{},"promises":["$@9","$@a"]}],null,["$","$Lb",null,{"children":["$Lc",["$","$Ld",null,{"promise":"$@e"}]]}]]}],{},null,false]},null,false],["$","$1","h",{"children":[null,[["$","$Lf",null,{"children":"$L10"}],null],["$","$L11",null,{"children":["$","div",null,{"hidden":true,"children":["$","$12",null,{"fallback":null,"children":"$L13"}]}]}]]}],false]],"m":"$undefined","G":["$14",[]],"s":false,"S":true}
9:{}
a:"$0:f:0:1:2:children:1:props:children:0:props:params"
10:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
c:null
15:I[80622,[],"IconMark"]
e:{"metadata":[["$","title","0",{"children":"Supernova | Web Portal"}],["$","meta","1",{"name":"description","content":"Advanced Enterprise Portal for SAP Business One"}],["$","link","2",{"rel":"icon","href":"/assets/logo.png"}],["$","$L15","3",{}]],"error":null,"digest":"$undefined"}
13:"$e:metadata"
